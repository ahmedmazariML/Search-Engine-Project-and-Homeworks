This file describes the main functionality and usage  of the search engine.


The program takes three parameters as input (in this order):
The indexation method: �stemmer� or �tokenizer�
Option to build or use previously built index: �build_index� or �use_index�
The search string 


By default the parameters are: tokenizer, use_index, empty search string.


Another thing that has to be configured before running the program is the path to the subindex folder and the text files, as well as the path to the index file(which will be built if it doesn�t exist).


// Directory which contains the text files
private static String DIR = "path_to_the_text_file";
	
// Path to SUBINDEX directory
private static String SUBINDEX = "path_to_subindex_folder/2015";
	
// PATH to index file- must be provided (if it doesn�t exist the file will be built)
private static String INDEX = "path_to_index.txt";


There are other parameters that can be changed or tuned before running the program:
The maximum number of files to be returned by the search method
A min threshold for the similarity between documents and search string (if the similarity of the search string and the document is smaller than this value we consider the document is not pertinent for the search string)


//threshold for documents similarity
private static final Double THRESHOLD = 0.01


// Maximum number of files to be returned as result of the search
private static int NR_FILES = 10;




Finally, the last parameter is the split for the path to text files (which is computed dynamically in the program while parsing the xml files in subindex).


//Split character for path : used for determining the path to text files
// For Linux this should be "/"
private static String split = "\\";


After configuring all these parameters, your program should be functional. 
Additional details on the main architecture of the program, as well as a discussion on the performance can be found on the project report file.
